package com.javatpoint;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloWorldController {
	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "123456789");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}

	@RequestMapping("/hello")
	public ModelAndView helloWorld(HttpServletRequest request, HttpServletResponse res) {
		String emp_id = request.getParameter("t1");
		String name = request.getParameter("t2");
		String address = request.getParameter("t3");
		String button = request.getParameter("submit");
		int a = Integer.parseInt(emp_id);

		try {
			if (button.equals("insert")) {
				Connection con = HelloWorldController.getConnection();
				PreparedStatement ps = con.prepareStatement("insert into users(emp_id,name,address) values (?,?,?)");
				ps.setInt(1, a);
				ps.setString(2, name);
				ps.setString(3, address);
				ps.executeUpdate();
				System.out.println("inserted");
				con.close();
			} else if (button.equals("update")) {
				Connection con = HelloWorldController.getConnection();
				PreparedStatement ps = con.prepareStatement("update users set name=? , address=? where emp_id=?");
				ps.setInt(3, a);
				ps.setString(1, name);
				ps.setString(2, address);
				ps.executeUpdate();
				System.out.println("updated");
				con.close();
			} else if (button.equals("delete")) {
				Connection con = HelloWorldController.getConnection();
				PreparedStatement ps = con.prepareStatement("delete from users where emp_id =?");
				
				ps.setString(1, emp_id);
				
				ps.executeUpdate();
				System.out.println("deleted");
				con.close();
			}

			else if (button.equals("select")) {
				Connection con = HelloWorldController.getConnection();
				PreparedStatement ps = con.prepareStatement("select * from users");
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					rs.getInt(1);
					rs.getString(2);
					rs.getString(3);
					ps.executeUpdate();
					System.out.println(a);
					System.out.println(name);
					System.out.println(address);
					con.close();
				}
			}
		}

		catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;

	}
}
