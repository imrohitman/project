package com.javatpoint;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloWorldController {
	@RequestMapping("/hello")
	public ModelAndView helloWorld(HttpServletRequest request, HttpServletResponse res) {
		String no1 = request.getParameter("n1");
		int a = Integer.parseInt(no1);
		String no2 = request.getParameter("n2");
		int b = Integer.parseInt(no2);
		String button = request.getParameter("submit");
		if (button.equals("add")) {
			int add = a+b;
			return new ModelAndView("hellopage", "add", add);
		}
		if (button.equals("sub")) {
			int sub = a-b;
			return new ModelAndView("hellopage", "sub", sub);
		} 
		if (button.equals("mul")) {
			int mul = a*b;
			return new ModelAndView("hellopage", "mul", mul);
		} 
		if (button.equals("div")) {
			int divide = a/b;
			return new ModelAndView("hellopage", "divide", divide);
		} 
		else {
			return new ModelAndView("errorpage", "message", "Sorry, username or password error");
		}
	}
}
