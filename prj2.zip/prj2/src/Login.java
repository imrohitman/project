import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/Log")
public class Login extends HttpServlet
 {
PreparedStatement st=null;
Connection con=null;
ResultSet rs=null;
int i=0;
public void init()
{
System.out.println("init");
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","123456789");
System.out.println("connected");
}
catch(Exception ae)
{}
}

    public void service(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException 
{
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
       
	String a=req.getParameter("t1");
	String b=req.getParameter("t2");
	
	 
 try 
{

st=con.prepareStatement("select * from Registration where t1=? and t6=?");
	st.setString(1,a);
	st.setString(2,b);
	rs=st.executeQuery();
	while(rs.next())
	{
	i=1;
res.sendRedirect("Login.jsp");
	}
if(i==1)
	res.sendRedirect("index.jsp");
else
	res.sendRedirect("Login.jsp");
	
}
catch(Exception at)
{}
             

            out.println("</body>");
            out.println("</html>");
              } 

 
}