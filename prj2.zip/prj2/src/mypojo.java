public class mypojo
{
	String uname,pword,cnfpwd,City,pin,mob;
	public String getCnfpwd() {
		return cnfpwd;
	}
	public void setCnfpwd(String cnfpwd) {
		this.cnfpwd = cnfpwd;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getMob() {
		return mob;
	}
	public void setMob(String mob) {
		this.mob = mob;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPword() {
		return pword;
	}
	public void setPword(String pword) {
		this.pword = pword;
	}
	
}